export class SafeSpace {
  enter() { /* placeholder */ }
  exit() { /* placeholder */ }
}

export interface VRComfortConfig {
  personalSpace: number
  safeSpace: { enabled: boolean }
  motion: { mode: 'teleport' | 'smooth'; comfort: 'low' | 'medium' | 'high' }
}

export class VRComfortZone {
  private personalSpaceRadius: number
  constructor(private cfg: VRComfortConfig) {
    this.personalSpaceRadius = cfg.personalSpace
  }

  setPersonalSpace(r: number) { this.personalSpaceRadius = r }

  proximity(distance: number) {
    if (distance < this.personalSpaceRadius) {
      return { breached: True, action: 'warn' }
    }
    return { breached: False }
  }
}

export class NeuroTestSuite {
  runAll() {
    return {
      accessibility: 'pending',
      cognitiveLoad: 'pending',
      sensory: 'pending'
    }
  }
}

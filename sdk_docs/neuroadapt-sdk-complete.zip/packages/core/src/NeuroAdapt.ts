import { SensoryManager } from './sensory/SensoryManager'
import { CognitiveLoadManager } from './cognitive/CognitiveLoadManager'
import { PreferenceStore } from './preferences/PreferenceStore'
import { AdaptableContent, NeuroAdaptConfig, AdaptedContent } from './types'

export class NeuroAdapt {
  private sensory: SensoryManager
  private cognitive: CognitiveLoadManager
  private preferences: PreferenceStore

  constructor(config?: NeuroAdaptConfig) {
    this.preferences = new PreferenceStore(config?.storage)
    this.sensory = new SensoryManager(this.preferences)
    this.cognitive = new CognitiveLoadManager(this.preferences)
  }

  async initialize(): Promise<void> {
    await this.preferences.load()
    await this.sensory.initialize()
    await this.cognitive.initialize()
  }

  getUserPreferences() {
    return this.preferences.getAll()
  }

  async adapt(content: AdaptableContent): Promise<AdaptedContent> {
    const prefs = this.getUserPreferences()
    let adapted = await this.sensory.adapt({ ...content }, prefs.sensory)
    adapted = await this.cognitive.adapt(adapted, prefs.cognitive)
    return adapted
  }
}

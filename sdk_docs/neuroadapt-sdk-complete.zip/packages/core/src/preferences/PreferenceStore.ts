import { PreferenceStorage, UserPreferences } from '../types'

class MemoryStorage implements PreferenceStorage {
  private data: any = null
  async load() { return this.data }
  async save(prefs: UserPreferences) { this.data = prefs }
}

const defaultPrefs: UserPreferences = {
  sensory: {
    visual: { brightness: 0.9, contrast: 1, colorTemp: 5000, motionTolerance: 'minimal' },
    auditory: { volumePreference: 0.6, frequencyFilters: [], spatialAudioTolerance: true, suddenSoundSensitivity: false },
    haptic: { intensity: 0.5, patterns: [], enabled: true }
  },
  cognitive: {
    explanationDepth: 'simple',
    preferredLearning: 'visual',
    chunkSize: 'small',
    attentionSpan: 'variable',
    breakReminders: true
  }
}

export class PreferenceStore {
  private storage: PreferenceStorage
  private prefs: UserPreferences = defaultPrefs

  constructor(storage?: PreferenceStorage) {
    this.storage = storage || new MemoryStorage()
  }

  async load() {
    const loaded = await this.storage.load()
    if (loaded) {
      this.prefs = { ...this.prefs, ...loaded }
    }
  }

  async save() {
    await this.storage.save(this.prefs)
  }

  getAll(): UserPreferences {
    return this.prefs
  }

  update(partial: Partial<UserPreferences>) {
    this.prefs = { ...this.prefs, ...partial }
    return this.save()
  }
}

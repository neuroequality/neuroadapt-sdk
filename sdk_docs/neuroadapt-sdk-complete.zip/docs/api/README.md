# API Reference

Generated via TypeDoc (run `npm run docs`).

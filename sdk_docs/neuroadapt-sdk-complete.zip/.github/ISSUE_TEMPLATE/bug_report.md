---
name: Bug report
about: Report a defect in NeuroAdapt SDK
labels: bug
---

**Describe the bug**
A clear description of the issue.

**Reproduction**
Steps to reproduce:
1.
2.

**Expected behavior**

**Environment**
- Package(s):
- Version:

**Additional context**

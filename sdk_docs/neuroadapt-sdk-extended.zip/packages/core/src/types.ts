export interface SensoryVisualPreferences {
  brightness: number
  contrast: number
  colorTemp: number
  motionTolerance: 'none' | 'minimal' | 'moderate' | 'full'
}

export interface SensoryAuditoryPreferences {
  volumePreference: number
  frequencyFilters: Array<{ low: number; high: number }>
  spatialAudioTolerance: boolean
  suddenSoundSensitivity: boolean
}

export interface SensoryHapticPreferences {
  intensity: number
  patterns: string[]
  enabled: boolean
}

export interface SensoryProfile {
  visual: SensoryVisualPreferences
  auditory: SensoryAuditoryPreferences
  haptic: SensoryHapticPreferences
}

export interface CognitivePreferences {
  explanationDepth?: 'simple' | 'intermediate' | 'detailed'
  preferredLearning?: 'visual' | 'verbal' | 'kinesthetic'
  chunkSize?: 'small' | 'medium' | 'large'
  attentionSpan?: 'short' | 'variable' | 'sustained'
  breakReminders?: boolean
}

export interface UserPreferences {
  sensory: SensoryProfile
  cognitive: CognitivePreferences
  [key: string]: any
}

export interface NeuroAdaptConfig {
  storage?: PreferenceStorage
}

export interface PreferenceStorage {
  load(): Promise<Partial<UserPreferences> | null>
  save(prefs: UserPreferences): Promise<void>
}

export interface AdaptableContent {
  text?: string
  html?: string
  [key: string]: any
}

export type AdaptedContent = AdaptableContent

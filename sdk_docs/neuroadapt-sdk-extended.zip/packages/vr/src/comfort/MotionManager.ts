export class MotionManager {
  constructor(private mode: 'teleport' | 'smooth') {}
  getMode() { return this.mode }
}

export class ConceptAdapter {
  simplify(concept: string, level: 'basic'|'intermediate'|'advanced') {
    if (level === 'basic') return `${concept} simplified overview`
    if (level === 'intermediate') return `${concept} moderate depth`
    return `${concept} full depth`
  }
}

import { test, expect } from '@playwright/test'
import AxeBuilder from '@axe-core/playwright'

test.describe('Launchpad accessibility', () => {
  test('home has no critical a11y violations', async ({ page }) => {
    await page.goto('http://localhost:4300')
    const accessibilityScanResults = await new AxeBuilder({ page }).analyze()
    const critical = accessibilityScanResults.violations.filter(v => v.impact === 'critical')
    expect(critical).toEqual([])
  })
})

#!/usr/bin/env node
console.log("Release helper - ensure CHANGELOG updated before tagging.")

import React, { useEffect, useState } from 'react'
import { NeuroAdapt } from '@neuroadapt/core'

export default function Home() {
  const [prefs, setPrefs] = useState<any>(null)

  useEffect(() => {
    const n = new NeuroAdapt()
    n.initialize().then(() => {
      setPrefs(n.getUserPreferences())
    })
  }, [])

  return (
    <main style={{ maxWidth: 960, margin: '0 auto', padding: 32 }}>
      <h1>NeuroAdapt Launchpad</h1>
      <p>Developer hub for exploring adaptive accessibility features.</p>
      <h2>Current Preferences</h2>
      <pre style={{ background:'#f5f5f5', padding:16 }}>{JSON.stringify(prefs, null, 2)}</pre>
      <section>
        <h2>Resources</h2>
        <ul>
          <li><a href="/docs/getting-started">Getting Started</a></li>
          <li><a href="https://github.com/neuroadapt/sdk">GitHub Repo</a></li>
        </ul>
      </section>
    </main>
  )
}

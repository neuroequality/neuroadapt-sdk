import { NeuroAgent } from '@neuroadapt/agents/neuroAgent';
import { AnthropicClient } from '@neuroadapt/anthropic/client';

const agent = new NeuroAgent(new AnthropicClient(process.env.ANTHROPIC_API_KEY!));
agent.assist('Help me plan my day with ADHD').then(console.log);
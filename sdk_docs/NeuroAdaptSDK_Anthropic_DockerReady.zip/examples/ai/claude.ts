import { AnthropicClient } from '@neuroadapt/anthropic/client';

const client = new AnthropicClient(process.env.ANTHROPIC_API_KEY!);
client.callClaude('What is neurodiversity?').then(console.log);
export interface SensoryProfile {
  brightness: number;
  contrast: number;
}

export class SensoryManager {
  constructor(private profile: SensoryProfile) {}
  apply(): void {
    console.log('Applying sensory settings:', this.profile);
  }
}
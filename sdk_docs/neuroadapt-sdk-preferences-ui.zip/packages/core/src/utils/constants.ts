export const DEFAULT_BRIGHTNESS = 0.9

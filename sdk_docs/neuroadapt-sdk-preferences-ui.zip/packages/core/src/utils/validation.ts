import { z } from 'zod'

export const SensoryVisualSchema = z.object({
  brightness: z.number().min(0).max(1),
  contrast: z.number().min(0).max(2),
  colorTemp: z.number().min(2000).max(8000),
  motionTolerance: z.enum(['none','minimal','moderate','full'])
})

export const SensoryAuditorySchema = z.object({
  volumePreference: z.number().min(0).max(1),
  frequencyFilters: z.array(z.object({ low: z.number(), high: z.number() })),
  spatialAudioTolerance: z.boolean(),
  suddenSoundSensitivity: z.boolean()
})

export const SensoryHapticSchema = z.object({
  intensity: z.number().min(0).max(1),
  patterns: z.array(z.string()),
  enabled: z.boolean()
})

export const SensoryProfileSchema = z.object({
  visual: SensoryVisualSchema,
  auditory: SensoryAuditorySchema,
  haptic: SensoryHapticSchema
})

export const CognitivePreferencesSchema = z.object({
  explanationDepth: z.enum(['simple','intermediate','detailed']).optional(),
  preferredLearning: z.enum(['visual','verbal','kinesthetic']).optional(),
  chunkSize: z.enum(['small','medium','large']).optional(),
  attentionSpan: z.enum(['short','variable','sustained']).optional(),
    breakReminders: z.boolean().optional()
})

export const UserPreferencesSchema = z.object({
  sensory: SensoryProfileSchema,
  cognitive: CognitivePreferencesSchema
})

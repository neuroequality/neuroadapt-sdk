import { AdaptableContent, CognitivePreferences, UserPreferences } from '../types'

export class CognitiveLoadManager {
  constructor(private prefsStore: any) {}

  async initialize() {}

  async adapt(content: AdaptableContent, cognitive: CognitivePreferences): Promise<AdaptableContent> {
    if (!content.text) return content
    // Basic chunking
    if (cognitive.chunkSize === 'small' && content.text.length > 400) {
      const raw = content.text.split(/(?<=\.)\s+/)
      const grouped: string[] = []
      let buffer = ''
      for (const sentence of raw) {
        if ((buffer + ' ' + sentence).trim().length > 220) {
          grouped.push(buffer.trim())
          buffer = sentence
        } else {
          buffer = (buffer + ' ' + sentence).trim()
        }
      }
      if (buffer) grouped.push(buffer)
      content.text = grouped.join('\n\n')
    }
    return content
  }
}

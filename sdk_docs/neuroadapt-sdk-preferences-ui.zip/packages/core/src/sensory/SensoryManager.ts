import { EventEmitter } from 'events'
import { PreferenceStore } from '../preferences/PreferenceStore'
import { UserPreferences, AdaptableContent, SensoryProfile } from '../types'

export class SensoryManager extends EventEmitter {
  private profile: SensoryProfile

  constructor(private prefs: PreferenceStore) {
    super()
    this.profile = this.prefs.getAll().sensory
  }

  async initialize() {
    // Placeholder for setting up hardware / environment watchers
  }

  async adapt(content: AdaptableContent, sensory: SensoryProfile): Promise<AdaptableContent> {
    // Example adaptation: adjust text markup (contrast hints etc.)
    if (content.text) {
      if (sensory.visual.motionTolerance === 'none') {
        content.text = content.text.replace(/\*\*/g, '') // remove bold emphasis as a placeholder
      }
    }
    return content
  }
}

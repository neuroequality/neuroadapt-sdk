
import React, { useState, useEffect } from 'react';
import { 
  Brain, Code, Book, Play, Download, Github, Package, 
  Zap, Eye, Volume2, Hand, MessageSquare, Sparkles,
  ChevronRight, Copy, Check, ExternalLink, Terminal,
  Settings, Users, FileCode, Boxes, BookOpen, Beaker
} from 'lucide-react';
import { NeuroAdapt } from '@neuroadapt/core';
import type { UserPreferences } from '@neuroadapt/core';

/**
 * NeuroAdapt Launchpad
 * Interactive developer portal UI with live preferences editing
 */
const NeuroAdaptLaunchpad: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview'|'components'|'examples'|'playground'|'preferences'>('overview');
  const [copiedCode, setCopiedCode] = useState<string>('');
  const [selectedComponent, setSelectedComponent] = useState<string>('sensory');
  const [demoMessage, setDemoMessage] = useState<string>('');
  const [adaptedResponse, setAdaptedResponse] = useState<string>('');
  const [demoActive, setDemoActive] = useState<boolean>(false);

  const [neuro, setNeuro] = useState<NeuroAdapt|null>(null);
  const [prefs, setPrefs] = useState<UserPreferences|null>(null);
  const [loadingPrefs, setLoadingPrefs] = useState<boolean>(true);

  // Initialize NeuroAdapt and load preferences
  useEffect(() => {
    const instance = new NeuroAdapt();
    instance.initialize().then(() => {
      setNeuro(instance);
      setPrefs(instance.getUserPreferences());
      setLoadingPrefs(false);
    });
  }, []);

  const updatePreference = (partial: Partial<UserPreferences>) => {
    if (!neuro) return;
    // update in store
    neuro['preferences'].update(partial);
    // update local state
    setPrefs((prev) => prev ? { ...prev, ...partial } : prev);
  };

  // Code examples unchanged ...
  const codeExamples: Record<string, string> = { /* ... existing examples ... */ };

  const copyToClipboard = (code: string, id: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(code).then(() => {
        setCopiedCode(id);
        setTimeout(() => setCopiedCode(''), 2000);
      });
    }
  };

  // Simulated adaptation ...
  const simulateClaudeAdaptation = async (...) => { /* unchanged */ };

  const components = [ /* unchanged */ ] as const;
  const StatusBadge = ({ status }: { status: string }) => { /* unchanged */ };

  const LiveDemo: React.FC = () => { /* unchanged */ };

  // Tab button component extended
  const TabButton = ({ tab, label }: { tab: typeof activeTab, label: string }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={\`px-6 py-2 rounded-lg font-medium transition-all \${activeTab === tab ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}\`}
    >
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header unchanged ... */}

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Hero + QuickStart + existing tabs ... */}
          <div className="flex flex-wrap gap-2 justify-center mb-8">
            {[
              { tab: 'overview', label: 'Overview' },
              { tab: 'components', label: 'Components' },
              { tab: 'examples', label: 'Examples' },
              { tab: 'playground', label: 'Playground' },
              { tab: 'preferences', label: 'Preferences' }
            ].map(({ tab, label }) => (
              <TabButton key={tab} tab={tab as any} label={label} />
            ))}
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            {loadingPrefs && activeTab === 'preferences' && <p>Loading preferences...</p>}

            {activeTab === 'preferences' && !loadingPrefs && prefs && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold mb-4">Edit User Preferences</h3>
                {/* Sensory Visual */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">Brightness ({prefs.sensory.visual.brightness})</label>
                    <input
                      type="range" min="0" max="1" step="0.1"
                      value={prefs.sensory.visual.brightness}
                      onChange={e => updatePreference({
                        sensory: {
                          ...prefs.sensory,
                          visual: { ...prefs.sensory.visual, brightness: parseFloat(e.target.value) }
                        }
                      })}
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Contrast ({prefs.sensory.visual.contrast})</label>
                    <input
                      type="range" min="0" max="2" step="0.1"
                      value={prefs.sensory.visual.contrast}
                      onChange={e => updatePreference({
                        sensory: { ...prefs.sensory, visual: { ...prefs.sensory.visual, contrast: parseFloat(e.target.value) } }
                      })}
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Motion Tolerance</label>
                    <select
                      value={prefs.sensory.visual.motionTolerance}
                      onChange={e => updatePreference({
                        sensory: {
                          ...prefs.sensory,
                          visual: { ...prefs.sensory.visual, motionTolerance: e.target.value as any }
                        }
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                    >
                      {['none','minimal','moderate','full'].map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Cognitive */}
                <div className="mt-4 grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">Explanation Depth</label>
                    <select
                      value={prefs.cognitive.explanationDepth}
                      onChange={e => updatePreference({
                        cognitive: { ...prefs.cognitive, explanationDepth: e.target.value as any }
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                    >
                      {['simple','intermediate','detailed'].map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={prefs.cognitive.breakReminders}
                      onChange={e => updatePreference({
                        cognitive: { ...prefs.cognitive, breakReminders: e.target.checked }
                      })}
                      className="rounded"
                    />
                    <span className="text-sm font-medium">Break Reminders</span>
                  </div>
                </div>
              </div>
            )}

            {/* Existing tab content for overview, components, examples, playground unchanged */}
            {/* ... */}
          </div>
        </div>
      </section>

      {/* Footer unchanged */}
      {/* ... */}
    </div>
  );
};

export default NeuroAdaptLaunchpad;

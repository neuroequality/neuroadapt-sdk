import NeuroAdaptLaunchpad from '../components/NeuroAdaptLaunchpad'
export default function Home() {
  return <NeuroAdaptLaunchpad />
}

#!/usr/bin/env node
console.log("Building all packages...")

# AI Integration Guide

How to connect Claude/OpenAI with adaptive preferences.

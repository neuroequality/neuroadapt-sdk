// VR Comfort Zone
export class ComfortZone {
  radius: number = 1.5;
  safeTrigger(): void {
    console.log("Safe zone activated.");
  }
}

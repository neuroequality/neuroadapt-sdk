// AI Adapter
export class PredictableAI {
  constructor(private tone: 'calm' | 'neutral' | 'direct') {}
  respond(input: string): string {
    return `[${this.tone}] ${input}`;
  }
}

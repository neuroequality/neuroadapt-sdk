// Sensory Manager
export interface SensoryProfile {
  brightness: number;
  contrast: number;
  motionTolerance: 'low' | 'medium' | 'high';
}

export class SensoryManager {
  private profile: SensoryProfile;
  constructor(profile: SensoryProfile) {
    this.profile = profile;
  }
  apply(): void {
    console.log('Applying sensory settings:', this.profile);
  }
}

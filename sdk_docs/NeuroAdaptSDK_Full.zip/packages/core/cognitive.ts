// Cognitive Load Manager
export class CognitiveLoadManager {
  overloadThreshold: number = 75;
  check(load: number): boolean {
    return load > this.overloadThreshold;
  }
}

import { SensoryManager } from '@neuroadapt/core/sensory';
const sensory = new SensoryManager({ brightness: 0.8, contrast: 1.0, motionTolerance: 'low' });
sensory.apply();

using System;

public class VRGame {
    public void Start() {
        Console.WriteLine("NeuroAdapt VR Comfort Zone Enabled");
    }
}

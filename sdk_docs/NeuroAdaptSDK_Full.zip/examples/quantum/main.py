from neuroadapt.quantum import QuantumVisualizer

qv = QuantumVisualizer()
qv.show_state("0| + 1|")

Vue integration example placeholder.

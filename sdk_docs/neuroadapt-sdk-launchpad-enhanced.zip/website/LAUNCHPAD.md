# Launchpad Usage

## Install Dependencies

```bash
cd website
npm install
npm run dev
```

Visit: http://localhost:4300

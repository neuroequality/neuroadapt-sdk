import React, { useState, useEffect } from 'react';
import { 
  Brain, Code, Book, Play, Download, Github, Package, 
  Zap, Eye, Volume2, Hand, MessageSquare, Sparkles,
  ChevronRight, Copy, Check, ExternalLink, Terminal,
  Settings, Users, FileCode, Boxes, BookOpen, Beaker
} from 'lucide-react';

/**
 * NeuroAdapt Launchpad
 * Interactive developer portal UI
 */
const NeuroAdaptLaunchpad: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview'|'components'|'examples'|'playground'>('overview');
  const [copiedCode, setCopiedCode] = useState<string>('');
  const [selectedComponent, setSelectedComponent] = useState<string>('sensory');
  const [demoMessage, setDemoMessage] = useState<string>('');
  const [adaptedResponse, setAdaptedResponse] = useState<string>('');
  const [demoActive, setDemoActive] = useState<boolean>(false);

  // Code examples (static)
  const codeExamples: Record<string, string> = {
    quickStart: `// Install NeuroAdapt SDK
npm install @neuroadapt/core @neuroadapt/ai

// Basic Usage
import { NeuroAdapt } from '@neuroadapt/core';
import { ClaudeAdapter } from '@neuroadapt/ai';

const neuro = new NeuroAdapt();
await neuro.initialize();

// Wrap Claude API with neurodiversity features
const claude = new ClaudeAdapter(process.env.ANTHROPIC_API_KEY!);

// Apply user preferences automatically
const response = await claude.complete({
  prompt: "Explain machine learning",
  adaptations: neuro.getUserPreferences()
});`,
    sensoryManagement: `import { SensoryManager } from '@neuroadapt/core';

// Initialize sensory preferences
// (In practice you'll obtain from PreferenceStore)
const sensory = new SensoryManager(/* preference store */);

// Real-time monitoring
sensory.on('overload-risk', (data) => {
  console.log('Sensory overload risk detected:', data);
  sensory.reduceStimulation();
});`,
    claudeIntegration: `import { ClaudeAdapter } from '@neuroadapt/ai';

// Initialize Claude with NeuroAdapt preferences
const claude = new ClaudeAdapter(process.env.ANTHROPIC_API_KEY!);

const response = await claude.complete({
  prompt: "Explain quantum entanglement",
  adaptations: neuro.getUserPreferences()
});

console.log(response.content);`,
    vrAccessibility: `import { VRComfortZone } from '@neuroadapt/vr';

const comfort = new VRComfortZone({
  personalSpace: 2.0,
  safeSpace: { enabled: true },
  motion: { mode: 'teleport', comfort: 'high' }
});`,
    quantumSimplifier: `import { QuantumVisualizer } from '@neuroadapt/quantum';

const qv = new QuantumVisualizer({ complexity: 'progressive', representations: ['visual'] });
console.log(qv.visualizeQubit({ theta: 1.2, phi: 0.7 }));`,
    customModel: `import { OllamaAdapter } from '@neuroadapt/ai';

const ollama = new OllamaAdapter('deepseek-r1:32b');

const resp = await ollama.complete({
  prompt: "Explain neural networks basically",
  adaptations: neuro.getUserPreferences()
});

console.log(resp.content);`
  };

  const copyToClipboard = (code: string, id: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(code).then(() => {
        setCopiedCode(id);
        setTimeout(() => setCopiedCode(''), 2000);
      });
    }
  };

  // Simulated adaptation (no external API call)
  const simulateClaudeAdaptation = async (message: string, preferences: any) => {
    setAdaptedResponse('Processing...');
    await new Promise(r => setTimeout(r, 600));
    let response = '';

    if (preferences.explanationLevel === 'simple') {
      response = `Simple explanation:
Machine learning teaches a computer to spot patterns by showing it many examples.

It improves gradually based on mistakes it makes.`;
    } else if (preferences.explanationLevel === 'detailed') {
      response = `Detailed explanation:
1. Training: model sees labeled examples.
2. Adjustment: it updates internal weights to reduce error.
3. Evaluation: we test on new data to check generalization.

Core pieces: data, model, optimization loop.`;
    } else {
      response = `Technical explanation:
Supervised ML minimizes a loss L(y, f(x; θ)) via gradient-based optimization (e.g. SGD).
Weights θ update iteratively until convergence or early stopping.`;
    }

    if (preferences.useVisualMetaphors) {
      response += `

🎨 Visual metaphor: It's like adjusting knobs on a mixing board until the output sound matches a target.`;
    }
    if (preferences.breakReminders) {
      response += `

💭 Optional pause: take a short break if this feels dense.`;
    }

    setAdaptedResponse(response);
  };

  const components = [
    { id: 'sensory', name: 'Sensory Management', icon: <Eye className="w-5 h-5" />, description: 'Manage visual, auditory, and haptic preferences', status: 'stable' },
    { id: 'cognitive', name: 'Cognitive Load Manager', icon: <Brain className="w-5 h-5" />, description: 'Monitor and adapt to cognitive capacity', status: 'stable' },
    { id: 'ai', name: 'AI Adapters', icon: <MessageSquare className="w-5 h-5" />, description: 'Claude & LLM integration', status: 'stable' },
    { id: 'vr', name: 'VR/AR Accessibility', icon: <Boxes className="w-5 h-5" />, description: 'Comfort zones & motion management', status: 'beta' },
    { id: 'quantum', name: 'Quantum Simplifier', icon: <Sparkles className="w-5 h-5" />, description: 'Quantum visualization', status: 'alpha' }
  ] as const;

  const StatusBadge = ({ status }: { status: string }) => {
    const colors: Record<string,string> = {
      stable: 'bg-green-100 text-green-800',
      beta: 'bg-yellow-100 text-yellow-800',
      alpha: 'bg-purple-100 text-purple-800'
    };
    return <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status]}`}>{status}</span>;
  };

  const LiveDemo: React.FC = () => {
    const [brightness, setBrightness] = useState<number>(100);
    const [contrast, setContrast] = useState<number>(100);
    const [textSize, setTextSize] = useState<number>(16);
    const [explanationLevel, setExplanationLevel] = useState<string>('simple');
    const [visualMetaphors, setVisualMetaphors] = useState<boolean>(true);
    const [breakReminders, setBreakReminders] = useState<boolean>(false);

    return (
      <div className="space-y-6">
        {/* Sensory Demo */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Eye className="w-5 h-5 text-green-600" />
            Live Sensory Adjustment Demo
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Brightness: {brightness}%
                </label>
                <input type="range" min="50" max="150" value={brightness} onChange={e=>setBrightness(Number(e.target.value))} className="w-full" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  Contrast: {contrast}%
                </label>
                <input type="range" min="50" max="150" value={contrast} onChange={e=>setContrast(Number(e.target.value))} className="w-full" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  Text Size: {textSize}px
                </label>
                <input type="range" min="12" max="24" value={textSize} onChange={e=>setTextSize(Number(e.target.value))} className="w-full" />
              </div>
            </div>
            <div
              className="bg-white rounded-lg p-6 border-2 border-gray-200"
              style={{ filter: `brightness(${brightness}%) contrast(${contrast}%)`, fontSize: `${textSize}px` }}
            >
              <h4 className="font-semibold mb-2">Sample Content</h4>
              <p className="text-gray-700 mb-4">
                This text automatically adjusts based on your sensory preferences.
              </p>
              <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                Interactive Button
              </button>
            </div>
          </div>
          <div className="mt-4 p-4 bg-blue-50 rounded-lg text-sm text-blue-800">
            <strong>Code:</strong> <code>sensory.setPreferences(&#123; brightness: {brightness/100}, contrast: {contrast/100} &#125;)</code>
          </div>
        </div>

        {/* AI Adaptation Demo */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-blue-600" />
            AI Response Adaptation Demo
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Explanation Level</label>
                <select value={explanationLevel} onChange={e=>setExplanationLevel(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <option value="simple">Simple</option>
                  <option value="detailed">Detailed</option>
                  <option value="technical">Technical</option>
                </select>
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={visualMetaphors} onChange={e=>setVisualMetaphors(e.target.checked)} />
                Use Visual Metaphors
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={breakReminders} onChange={e=>setBreakReminders(e.target.checked)} />
                Include Break Reminders
              </label>
              <div>
                <label className="block text-sm font-medium mb-2">Test Message</label>
                <input
                  type="text"
                  value={demoMessage}
                  onChange={e=>setDemoMessage(e.target.value)}
                  placeholder="What is machine learning?"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <button
                onClick={() => simulateClaudeAdaptation(demoMessage || "What is machine learning?", {
                  explanationLevel,
                  useVisualMetaphors: visualMetaphors,
                  breakReminders
                })}
                className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              >
                Generate Adapted Response
              </button>
            </div>
            <div className="bg-white rounded-lg p-6 border-2 border-gray-200">
              <h4 className="font-semibold mb-2">Adapted AI Response</h4>
              <div className="text-gray-700 whitespace-pre-wrap text-sm">
                {adaptedResponse || 'Click "Generate Adapted Response" to simulate adaptation.'}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const TabButton = ({ tab }: { tab: 'overview'|'components'|'examples'|'playground' }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`px-6 py-2 rounded-lg font-medium transition-all ${
        activeTab === tab ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'
      }`}
    >
      {tab.charAt(0).toUpperCase() + tab.slice(1)}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">NeuroAdapt SDK</h1>
              <p className="text-sm text-gray-600">Launch Pad for Developers</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="https://github.com/neuroadapt/sdk" className="flex items-center gap-2 text-gray-700 hover:text-gray-900">
              <Github className="w-5 h-5" /> GitHub
            </a>
            <a href="/docs/getting-started" className="flex items-center gap-2 text-gray-700 hover:text-gray-900">
              <Book className="w-5 h-5" /> Docs
            </a>
            <button
              onClick={() => copyToClipboard('npm install @neuroadapt/core @neuroadapt/ai', 'install')}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <Download className="w-4 h-4" /> Install SDK
            </button>
          </nav>
        </div>
      </header>

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Hero */}
            <div className="text-center mb-10">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Build Accessible AI, VR & Quantum Apps</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                The NeuroAdapt SDK enables inclusive, adaptive experiences for neurodivergent users across emerging technology domains.
              </p>
            </div>

            {/* Quick Start */}
            <div className="bg-gray-900 rounded-lg p-6 mb-10">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-semibold flex items-center gap-2">
                  <Terminal className="w-5 h-5" /> Quick Start
                </h3>
                <button
                  onClick={() => copyToClipboard(codeExamples.quickStart, 'quickstart')}
                  className="text-gray-400 hover:text-white"
                >
                  {copiedCode === 'quickstart' ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                </button>
              </div>
              <pre className="text-green-400 font-mono text-sm overflow-x-auto">
                <code>{codeExamples.quickStart}</code>
              </pre>
            </div>

            {/* Tabs */}
            <div className="flex flex-wrap gap-2 justify-center mb-8">
              {(['overview','components','examples','playground'] as const).map(tab => <TabButton key={tab} tab={tab} />)}
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
              {activeTab === 'overview' && (
                <div className="space-y-8">
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="text-center p-6 rounded-lg bg-gradient-to-br from-blue-50 to-indigo-50">
                      <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <Zap className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-lg mb-2">Plug & Play</h3>
                      <p className="text-gray-600">Single-line initialization & adaptive defaults</p>
                    </div>
                    <div className="text-center p-6 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50">
                      <div className="w-16 h-16 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <Brain className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-lg mb-2">AI-Powered</h3>
                      <p className="text-gray-600">Predictable, explainable LLM integrations</p>
                    </div>
                    <div className="text-center p-6 rounded-lg bg-gradient-to-br from-green-50 to-emerald-50">
                      <div className="w-16 h-16 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <Users className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-lg mb-2">Community-Driven</h3>
                      <p className="text-gray-600">Built with neurodivergent contributors</p>
                    </div>
                  </div>

                  <div className="border-t pt-8">
                    <h3 className="text-2xl font-bold mb-4">Why NeuroAdapt?</h3>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold mb-2">For Developers</h4>
                        <ul className="space-y-2 text-gray-600">
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-green-600" /> TypeScript-first</li>
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-green-600" /> Framework agnostic</li>
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-green-600" /> Extensive examples</li>
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-green-600" /> Built-in testing</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">For Users</h4>
                        <ul className="space-y-2 text-gray-600">
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-blue-600" /> Sensory load reduction</li>
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-blue-600" /> Cognitive adaptation</li>
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-blue-600" /> Multiple modalities</li>
                          <li className="flex gap-2"><ChevronRight className="w-5 h-5 text-blue-600" /> Privacy-respecting</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'components' && (
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold mb-6">SDK Components</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {components.map(c => (
                      <button
                        key={c.id}
                        onClick={() => setSelectedComponent(c.id)}
                        className={`p-6 rounded-lg border-2 text-left transition-all ${
                          selectedComponent === c.id ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className={`p-2 rounded-lg ${selectedComponent === c.id ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}>{c.icon}</div>
                          <StatusBadge status={c.status} />
                        </div>
                        <h4 className="font-semibold text-lg mb-1">{c.name}</h4>
                        <p className="text-gray-600 text-sm">{c.description}</p>
                      </button>
                    ))}
                  </div>
                  {selectedComponent && (
                    <div className="mt-8 p-6 bg-gray-50 rounded-lg">
                      <h4 className="font-semibold text-lg mb-4">Installation & Usage</h4>
                      <div className="bg-gray-900 rounded-lg p-4 mb-4">
                        <code className="text-green-400 font-mono text-sm">
                          npm install @neuroadapt/{selectedComponent}
                        </code>
                      </div>
                      <p className="text-gray-600 text-sm">
                        View full documentation for the <span className="font-semibold">{selectedComponent}</span> component in the API Reference.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'examples' && (
                <div className="space-y-8">
                  <h3 className="text-2xl font-bold mb-6">Code Examples</h3>
                  {[
                    { id: 'claude', title: 'Claude API Integration', icon: <MessageSquare className="w-5 h-5 text-blue-600" />, code: codeExamples.claudeIntegration },
                    { id: 'sensory', title: 'Sensory Management', icon: <Eye className="w-5 h-5 text-green-600" />, code: codeExamples.sensoryManagement },
                    { id: 'custom', title: 'Custom Model (DeepSeek R1)', icon: <Sparkles className="w-5 h-5 text-purple-600" />, code: codeExamples.customModel }
                  ].map(block => (
                    <div key={block.id} className="border rounded-lg overflow-hidden">
                      <div className="bg-gray-50 px-4 py-3 border-b flex items-center justify-between">
                        <h4 className="font-semibold flex items-center gap-2">{block.icon}{block.title}</h4>
                        <button
                          onClick={() => copyToClipboard(block.code, block.id)}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          {copiedCode === block.id ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                        </button>
                      </div>
                      <pre className="p-4 overflow-x-auto bg-gray-900 text-gray-200">
                        <code className="text-sm font-mono">{block.code}</code>
                      </pre>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'playground' && (
                <div className="space-y-8">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-2xl font-bold">Interactive Playground</h3>
                    <button
                      onClick={() => setDemoActive(!demoActive)}
                      className={`px-4 py-2 rounded-lg font-medium ${
                        demoActive ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700'
                      }`}
                    >
                      {demoActive ? 'Demo Active' : 'Start Demo'}
                    </button>
                  </div>
                  {demoActive ? <LiveDemo /> : (
                    <div className="text-center py-12 text-gray-600">
                      <Play className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <p className="text-lg">Click "Start Demo" to explore interactive examples</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Resources */}
            <div className="mt-12 grid md:grid-cols-4 gap-6">
              <a href="/docs/getting-started" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <FileCode className="w-8 h-8 text-blue-600 mb-3" />
                <h4 className="font-semibold mb-1">API Reference</h4>
                <p className="text-sm text-gray-600">Complete TypeScript API documentation</p>
              </a>
              <a href="/docs/integration-ai" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <BookOpen className="w-8 h-8 text-green-600 mb-3" />
                <h4 className="font-semibold mb-1">Tutorials</h4>
                <p className="text-sm text-gray-600">Step-by-step guides and examples</p>
              </a>
              <a href="https://github.com/neuroadapt/sdk" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <Users className="w-8 h-8 text-purple-600 mb-3" />
                <h4 className="font-semibold mb-1">Community</h4>
                <p className="text-sm text-gray-600">Join discussions & contribute</p>
              </a>
              <a href="#" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <Beaker className="w-8 h-8 text-orange-600 mb-3" />
                <h4 className="font-semibold mb-1">Research</h4>
                <p className="text-sm text-gray-600">Papers & validation studies</p>
              </a>
            </div>
        </div>
      </section>

      <footer className="bg-gray-900 text-gray-300 py-12 px-4 mt-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold text-white">NeuroAdapt</span>
              </div>
              <p className="text-sm">Building inclusive technology for all minds.</p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/docs/getting-started" className="hover:text-white">Documentation</a></li>
                <li><a href="/docs/integration-ai" className="hover:text-white">API Reference</a></li>
                <li><a href="https://github.com/neuroadapt/sdk" className="hover:text-white">Examples</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Community</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://github.com/neuroadapt/sdk" className="hover:text-white">GitHub</a></li>
                <li><a href="#" className="hover:text-white">Discord</a></li>
                <li><a href="#" className="hover:text-white">Twitter</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">MIT License</a></li>
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Code of Conduct</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm">
            <p>&copy; {new Date().getFullYear()} NeuroAdapt SDK. Open source under MIT License.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default NeuroAdaptLaunchpad;

export default function GettingStarted() {
  return <div style={{padding:32}}>
    <h1>Getting Started</h1>
    <p>This page will be populated with live docs integrated from the /docs folder.</p>
  </div>
}

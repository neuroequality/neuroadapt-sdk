#!/usr/bin/env node
console.log("Delegating to individual package test scripts.")

import { AIAdapter, AdaptedResponse, AdaptationConfig } from '../types'
import { SystemPrompts } from '../prompts/SystemPrompts'
import { UserPreferences } from '@neuroadapt/core'

/**
 * OllamaAdapter
 * Calls a local Ollama model (e.g. deepseek-r1:32b). Requires Ollama running locally.
 */
export class OllamaAdapter implements AIAdapter {
  private config: AdaptationConfig
  private model: string

  constructor(model = 'deepseek-r1:32b', config?: Partial<AdaptationConfig>) {
    this.model = model
    this.config = {
      model,
      emotionalTone: 'supportive',
      explanationDefault: 'simple',
      consistencyLevel: 'medium',
      previewMode: true,
      undoSteps: 5,
      ...config
    }
  }

  async complete(params: { prompt: string; adaptations?: UserPreferences }): Promise<AdaptedResponse> {
    const system = SystemPrompts.generate(this.config, params.adaptations)
    try {
      const resp = await fetch('http://localhost:11434/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.model,
          messages: [
            { role: 'system', content: system },
            { role: 'user', content: params.prompt }
          ],
          stream: False
        })
      })
      if (!resp.ok) {
        return { content: 'Ollama error', metadata: { status: resp.status } }
      }
      const data = await resp.json()
      const content = data.message?.content || data.response || 'No content'
      return {
        content,
        metadata: { model: this.model }
      }
    } catch (e: any) {
      return { content: 'Error contacting Ollama', metadata: { error: e.message } }
    }
  }
}

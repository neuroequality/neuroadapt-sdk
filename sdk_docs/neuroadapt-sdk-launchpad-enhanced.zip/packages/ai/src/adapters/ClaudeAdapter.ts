import Anthropic from '@anthropic-ai/sdk'
import { AIAdapter, AdaptedResponse, AdaptationConfig } from '../types'
import { SystemPrompts } from '../prompts/SystemPrompts'
import { UserPreferences } from '@neuroadapt/core'

export class ClaudeAdapter implements AIAdapter {
  private client: Anthropic
  private config: AdaptationConfig

  constructor(apiKey: string, config?: Partial<AdaptationConfig>) {
    this.client = new Anthropic({ apiKey })
    this.config = {
      model: 'claude-3-opus-20240229',
      emotionalTone: 'supportive',
      explanationDefault: 'simple',
      consistencyLevel: 'high',
      previewMode: true,
      undoSteps: 3,
      ...config
    }
  }

  async complete(params: { prompt: string; adaptations?: UserPreferences }): Promise<AdaptedResponse> {
    const system = SystemPrompts.generate(this.config, params.adaptations)
    try {
      const resp = await this.client.messages.create({
        model: this.config.model,
        system,
        max_tokens: 512,
        messages: [{ role: 'user', content: params.prompt }]
      })
      const content = resp.content[0].type === 'text' ? resp.content[0].text : JSON.stringify(resp.content[0])
      return {
        content,
        metadata: {
          model: this.config.model,
          tokens: resp.usage,
          consistency: this.config.consistencyLevel
        }
      }
    } catch (e: any) {
      return {
        content: 'Error generating response',
        metadata: { error: e.message }
      }
    }
  }
}

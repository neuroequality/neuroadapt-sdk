import { AIAdapter, AdaptedResponse, AdaptationConfig } from '../types'
import { SystemPrompts } from '../prompts/SystemPrompts'
import { UserPreferences } from '@neuroadapt/core'

/**
 * OpenAIAdapter
 * Wraps OpenAI Chat Completions (gpt-4o / gpt-4-turbo) with adaptation.
 * This is a lightweight wrapper; replace fetch endpoint / payload as API evolves.
 */
export class OpenAIAdapter implements AIAdapter {
  private apiKey: string
  private config: AdaptationConfig

  constructor(apiKey: string, config?: Partial<AdaptationConfig>) {
    this.apiKey = apiKey
    this.config = {
      model: 'gpt-4o',
      emotionalTone: 'supportive',
      explanationDefault: 'simple',
      consistencyLevel: 'high',
      previewMode: true,
      undoSteps: 3,
      ...config
    }
  }

  async complete(params: { prompt: string; adaptations?: UserPreferences }): Promise<AdaptedResponse> {
    const system = SystemPrompts.generate(this.config, params.adaptations)
    try {
      const body = {
        model: this.config.model,
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: params.prompt }
        ],
        temperature: 0.4
      }

      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      })

      if (!resp.ok) {
        return {
          content: 'OpenAI API error',
          metadata: { status: resp.status, statusText: resp.statusText }
        }
      }
      const data = await resp.json()
      const content = data.choices?.[0]?.message?.content || 'No content'
      return {
        content,
        metadata: {
          model: this.config.model,
          usage: data.usage
        }
      }
    } catch (e: any) {
      return { content: 'Error contacting OpenAI', metadata: { error: e.message } }
    }
  }
}

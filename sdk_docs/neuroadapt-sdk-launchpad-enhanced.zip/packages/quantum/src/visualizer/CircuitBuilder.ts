export class CircuitBuilder {
  private gates: string[] = []
  add(gate: string) { this.gates.push(gate) }
  list() { return this.gates }
}

---
name: Accessibility issue
about: Report an accessibility or inclusion concern
labels: accessibility
---

**Issue summary**

**Impacted users / profiles**

**Reproduction**

**Suggested remediation**

**Additional context**

import { AdaptationConfig } from '../types'
import { UserPreferences } from '@neuroadapt/core'

export class SystemPrompts {
  static generate(config: AdaptationConfig, prefs?: UserPreferences): string {
    let base = `You are NeuroAdapt, an AI assistant focused on accessibility and inclusive communication.
Use ${config.emotionalTone} language. Default to ${config.explanationDefault} explanations.
Maintain ${config.consistencyLevel} behavioral consistency.`

    if (prefs) {
      if (prefs.cognitive?.preferredLearning === 'visual') {
        base += '\nInclude visual analogies.'
      }
      if (prefs.cognitive?.chunkSize === 'small') {
        base += '\nKeep paragraphs short.'
      }
    }
    return base
  }
}

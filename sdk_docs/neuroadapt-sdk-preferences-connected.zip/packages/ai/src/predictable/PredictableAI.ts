import { AdaptedResponse } from '../types'

export class PredictableAI {
  constructor(private opts: { seed?: string; tone?: string } = {}) {}

  normalize(text: string): string {
    // Deterministic placeholder
    return text.trim()
  }

  postProcess(content: string): AdaptedResponse {
    return {
      content: this.normalize(content),
      metadata: { tone: this.opts.tone || 'neutral' }
    }
  }
}

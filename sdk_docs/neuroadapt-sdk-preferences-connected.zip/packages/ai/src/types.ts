import { UserPreferences } from '@neuroadapt/core'

export interface AdaptationConfig {
  model: string
  emotionalTone: string
  explanationDefault: 'simple' | 'intermediate' | 'detailed'
  consistencyLevel: 'low' | 'medium' | 'high'
  previewMode?: boolean
  undoSteps?: number
}

export interface AdaptedResponse {
  content: string
  metadata: Record<string, any>
}

export interface AIAdapter {
  complete(params: { prompt: string; adaptations?: UserPreferences }): Promise<AdaptedResponse>
}

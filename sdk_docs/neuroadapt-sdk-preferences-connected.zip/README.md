# NeuroAdapt SDK

<p align="center">
  <strong>Build accessible AI, VR, and quantum applications for neurodivergent users</strong>
</p>

<p align="center">
  <a href="https://github.com/neuroadapt/sdk/actions"><img src="https://github.com/neuroadapt/sdk/workflows/CI/badge.svg" alt="Build Status"></a>
  <a href="./LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="License"></a>
  <a href="https://www.npmjs.com/package/@neuroadapt/core"><img src="https://img.shields.io/npm/v/@neuroadapt/core.svg" alt="npm version"></a>
</p>

## 🚀 Quick Start

```bash
# Install selected packages
npm install @neuroadapt/core @neuroadapt/ai
```

```ts
import { NeuroAdapt } from '@neuroadapt/core'
import { ClaudeAdapter } from '@neuroadapt/ai'

const neuro = new NeuroAdapt()
await neuro.initialize()

const claude = new ClaudeAdapter(process.env.ANTHROPIC_API_KEY!)
const response = await claude.complete({
  prompt: "Explain quantum computing simply",
  adaptations: neuro.getUserPreferences()
})
console.log(response.content)
```

## 📦 Packages
- **@neuroadapt/core** – Core SDK, sensory + cognitive + preferences
- **@neuroadapt/ai** – LLM adapters (Claude, OpenAI, Ollama) + predictable AI layer
- **@neuroadapt/vr** – VR/AR comfort & safe space utilities
- **@neuroadapt/quantum** – Quantum visualization & concept adaptation
- **@neuroadapt/testing** – Neurodiversity simulation & validation suite

## 🌟 Features
| Domain | Capabilities |
|--------|--------------|
| Cognitive | Load monitoring, progressive disclosure, pacing |
| Sensory | Visual/audio/haptic adaptation, overload protection |
| AI | Predictable responses, explanation tiers, tone control |
| VR/AR | Personal space bubbles, motion comfort, safe spaces |
| Quantum | Multi-sensory qubit viz, circuit builder, complexity scaling |
| Testing | Simulation harness, accessibility & cognitive reports |

## 📚 Documentation
See `./docs/getting-started.md` and module guides inside `docs/guides/`.

## 🤝 Contributing
See `docs/contributing.md`. We welcome issues & PRs. Please include tests and follow the accessibility check pipeline.

## 🛡️ License
MIT – See `LICENSE`.

## 🙏 Acknowledgments
Built with input from neurodivergent contributors & advisors. This is a living project; feedback drives evolution.

### New: Preferences Panel
Live editing of sensory & cognitive settings via Launchpad (tab **Preferences**). Stored in localStorage.

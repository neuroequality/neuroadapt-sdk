import { QuantumVisualizer } from '@neuroadapt/quantum/src/visualizer/QuantumVisualizer'
const qv = new QuantumVisualizer()
console.log(qv.visualizeQubit({ theta: 1.2, phi: 0.7 }))

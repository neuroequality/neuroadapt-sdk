import { NeuroAdapt } from '@neuroadapt/core'
import { ClaudeAdapter } from '@neuroadapt/ai'

async function run() {
  const neuro = new NeuroAdapt()
  await neuro.initialize()
  const claude = new ClaudeAdapter(process.env.ANTHROPIC_API_KEY || '')
  const resp = await claude.complete({ prompt: 'Help me focus my tasks', adaptations: neuro.getUserPreferences() })
  console.log(resp)
}

run()

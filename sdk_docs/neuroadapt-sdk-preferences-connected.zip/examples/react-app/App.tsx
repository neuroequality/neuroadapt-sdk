import React from 'react'
import { NeuroAdapt } from '@neuroadapt/core'
import { ClaudeAdapter } from '@neuroadapt/ai'

export function App() {
  const [answer, setAnswer] = React.useState('')
  const neuroRef = React.useRef<NeuroAdapt>()

  React.useEffect(() => {
    const neuro = new NeuroAdapt()
    neuro.initialize().then(() => {
      neuroRef.current = neuro
    })
  }, [])

  async function ask() {
    if (!neuroRef.current) return
    const claude = new ClaudeAdapter(process.env.ANTHROPIC_API_KEY || '')
    const resp = await claude.complete({
      prompt: 'Explain superposition simply',
      adaptations: neuroRef.current.getUserPreferences()
    })
    setAnswer(resp.content)
  }

  return <div>
    <h1>NeuroAdapt React Example</h1>
    <button onClick={ask}>Ask</button>
    <pre>{answer}</pre>
  </div>
}

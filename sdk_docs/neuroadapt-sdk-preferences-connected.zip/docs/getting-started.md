# Getting Started

Install packages and initialize NeuroAdapt as shown.

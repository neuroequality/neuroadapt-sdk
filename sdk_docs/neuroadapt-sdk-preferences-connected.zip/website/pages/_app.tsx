import type { AppProps } from 'next/app'
import '../styles/globals.css'

import { NeuroAdaptProvider } from '../context/NeuroAdaptContext'

export default function App({ Component, pageProps }: AppProps) {
  return <NeuroAdaptProvider><Component {...pageProps} /></NeuroAdaptProvider>
}

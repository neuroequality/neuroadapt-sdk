
import React, { useState, useEffect } from 'react';
import { 
  Brain, Eye, MessageSquare, Check, Copy, Terminal, Zap, Users, Github, Book, Download,
  ChevronRight, Play, Boxes, Sparkles, FileCode, BookOpen, Beaker
} from 'lucide-react';
import { NeuroAdapt } from '@neuroadapt/core';
import type { UserPreferences } from '@neuroadapt/core';
import classNames from 'classnames';

/**
 * NeuroAdapt Launchpad
 * Interactive developer portal UI with live preferences editing, persistence, and integrated demos.
 */
const NeuroAdaptLaunchpad: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview'|'components'|'examples'|'playground'|'preferences'>('overview');
  const [copiedCode, setCopiedCode] = useState<string>('');
  const [selectedComponent, setSelectedComponent] = useState<'sensory'|'cognitive'|'ai'|'vr'|'quantum'>('sensory');
  const [demoMessage, setDemoMessage] = useState<string>('');
  const [adaptedResponse, setAdaptedResponse] = useState<string>('');
  const [demoActive, setDemoActive] = useState<boolean>(false);

  const [neuro, setNeuro] = useState<NeuroAdapt|null>(null);
  const [prefs, setPrefs] = useState<UserPreferences|null>(null);

  // Key for localStorage
  const STORAGE_KEY = 'neuroadapt_prefs';

  // Initialize NeuroAdapt, load saved prefs, and apply
  useEffect(() => {
    const instance = new NeuroAdapt();
    instance.initialize().then(() => {
      // Load from localStorage
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          const partial = JSON.parse(saved) as Partial<UserPreferences>;
          instance['preferences'].update(partial);
        } catch {}
      }
      const current = instance.getUserPreferences();
      setNeuro(instance);
      setPrefs(current);
    });
  }, []);

  // Persist and update both store and state
  const updatePreference = (partial: Partial<UserPreferences>) => {
    if (!neuro || !prefs) return;
    neuro['preferences'].update(partial);
    const merged = { ...prefs, ...partial };
    setPrefs(merged);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
  };

  // Code examples (static)
  const codeExamples: Record<string, string> = { /* ... existing code examples ... */ };

  // Copy helper
  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code).then(() => {
      setCopiedCode(id);
      setTimeout(() => setCopiedCode(''), 2000);
    });
  };

  // Simulate adaptation using live prefs
  const simulateAdaptation = async () => {
    if (!prefs) return;
    setAdaptedResponse('Processing...');
    await new Promise(r => setTimeout(r, 600));
    // Basic demonstration using prefs
    let resp = '';
    const level = prefs.cognitive.explanationDepth || 'simple';
    if (level === 'simple') {
      resp = 'Simple: ' + prefs.sensory.visual.brightness.toFixed(1) + ' brightness, ...';
    } else {
      resp = 'Detailed: using your preferences, brightness ' + prefs.sensory.visual.brightness;
    }
    setAdaptedResponse(resp);
  };

  // Components list
  const components = [
    { id: 'sensory', name: 'Sensory Management', icon: <Eye />, status: 'stable' },
    { id: 'cognitive', name: 'Cognitive Load Manager', icon: <Brain />, status: 'stable' },
    { id: 'ai', name: 'AI Adapters', icon: <MessageSquare />, status: 'stable' },
    { id: 'vr', name: 'VR/AR Accessibility', icon: <Boxes />, status: 'beta' },
    { id: 'quantum', name: 'Quantum Simplifier', icon: <Sparkles />, status: 'alpha' }
  ] as const;

  const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
    const colors: Record<string,string> = {
      stable: 'bg-green-100 text-green-800',
      beta: 'bg-yellow-100 text-yellow-800',
      alpha: 'bg-purple-100 text-purple-800'
    };
    return <span className={\`px-2 py-1 rounded-full text-xs font-medium \${colors[status]}\`}>{status}</span>;
  };

  // Live demo uses prefs directly
  const LiveDemo: React.FC = () => {
    if (!prefs) return null;
    return (
      <div className="space-y-6">
        {/* Sensory Demo */}
        <div>
          <h3>Sensory Demo</h3>
          <div style={{
            filter: \`brightness(\${prefs.sensory.visual.brightness*100}%) contrast(\${prefs.sensory.visual.contrast*100}%)\`
          }}>
            <p>Brightness: {prefs.sensory.visual.brightness}</p>
            <p>Contrast: {prefs.sensory.visual.contrast}</p>
          </div>
        </div>
        {/* AI Demo */}
        <div>
          <h3>AI Demo</h3>
          <button onClick={simulateAdaptation}>Simulate Adaptation</button>
          <pre>{adaptedResponse}</pre>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen">
      {/* Tabs */}
      <div className="flex space-x-2">
        {['overview','components','examples','playground','preferences'].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={classNames('px-4 py-2', activeTab===tab ? 'bg-blue-600 text-white' : 'bg-gray-200')}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="p-6">
        {activeTab === 'preferences' && prefs && (
          <div className="space-y-4">
            <h2>Edit Preferences</h2>
            <label>Brightness: {prefs.sensory.visual.brightness}</label>
            <input type="range" min={0} max={1} step={0.1}
              value={prefs.sensory.visual.brightness}
              onChange={e => updatePreference({
                sensory: {
                  ...prefs.sensory,
                  visual: { ...prefs.sensory.visual, brightness: parseFloat(e.target.value) }
                }
              })}
            />
            <label>Contrast: {prefs.sensory.visual.contrast}</label>
            <input type="range" min={0} max={2} step={0.1}
              value={prefs.sensory.visual.contrast}
              onChange={e => updatePreference({
                sensory: { ...prefs.sensory, visual: { ...prefs.sensory.visual, contrast: parseFloat(e.target.value) } }
              })}
            />
            <label>Explanation Depth:</label>
            <select value={prefs.cognitive.explanationDepth}
              onChange={e => updatePreference({
                cognitive: { ...prefs.cognitive, explanationDepth: e.target.value as any }
              })}
            >
              {['simple','intermediate','detailed'].map(o => (
                <option key={o} value={o}>{o}</option>
              ))}
            </select>
            <label><input type="checkbox"
              checked={prefs.cognitive.breakReminders}
              onChange={e => updatePreference({
                cognitive: { ...prefs.cognitive, breakReminders: e.target.checked }
              })}
            /> Break Reminders</label>
          </div>
        )}
        {activeTab === 'playground' && <LiveDemo />}
      </div>
    </div>
  );
};

export default NeuroAdaptLaunchpad;

import React, { useState, useEffect } from 'react'
import { useNeuroAdapt } from '../context/NeuroAdaptContext'
import { Check, Save, AlertCircle } from 'lucide-react'

interface FieldError { field: string; message: string }

const numberField = (label: string, value: number, setter: (v: number)=>void, min: number, max: number, step=0.1) => (
  <div className="space-y-1">
    <label className="block text-sm font-medium text-gray-700">{label} <span className="text-xs text-gray-500">({value})</span></label>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={e => setter(Number(e.target.value))}
      className="w-full"
    />
  </div>
)

export const PreferencesPanel: React.FC = () => {
  const { preferences, updatePreferences } = useNeuroAdapt()
  const [brightness, setBrightness] = useState(0.9)
  const [contrast, setContrast] = useState(1)
  const [colorTemp, setColorTemp] = useState(5000)
  const [motionTolerance, setMotionTolerance] = useState<'none'|'minimal'|'moderate'|'full'>('minimal')
  const [volume, setVolume] = useState(0.6)
  const [suddenSoundSensitivity, setSuddenSoundSensitivity] = useState(false)
  const [explanationDepth, setExplanationDepth] = useState<'simple'|'intermediate'|'detailed'>('simple')
  const [preferredLearning, setPreferredLearning] = useState<'visual'|'verbal'|'kinesthetic'>('visual')
  const [chunkSize, setChunkSize] = useState<'small'|'medium'|'large'>('small')
  const [attentionSpan, setAttentionSpan] = useState<'short'|'variable'|'sustained'>('variable')
  const [breakReminders, setBreakReminders] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [errors, setErrors] = useState<FieldError[]>([])

  useEffect(() => {
    if (preferences) {
      setBrightness(preferences.sensory.visual.brightness)
      setContrast(preferences.sensory.visual.contrast)
      setColorTemp(preferences.sensory.visual.colorTemp)
      setMotionTolerance(preferences.sensory.visual.motionTolerance)
      setVolume(preferences.sensory.auditory.volumePreference)
      setSuddenSoundSensitivity(preferences.sensory.auditory.suddenSoundSensitivity)
      setExplanationDepth(preferences.cognitive.explanationDepth || 'simple')
      setPreferredLearning(preferences.cognitive.preferredLearning || 'visual')
      setChunkSize(preferences.cognitive.chunkSize || 'small')
      setAttentionSpan(preferences.cognitive.attentionSpan || 'variable')
      setBreakReminders(!!preferences.cognitive.breakReminders)
    }
  }, [preferences])

  const validate = (): boolean => {
    const errs: FieldError[] = []
    if (brightness < 0 || brightness > 1) errs.push({ field: 'brightness', message: 'Brightness out of range (0-1)' })
    if (contrast < 0 || contrast > 2) errs.push({ field: 'contrast', message: 'Contrast out of range (0-2)' })
    if (colorTemp < 2000 || colorTemp > 8000) errs.push({ field: 'colorTemp', message: 'Color temperature must be 2000-8000K' })
    if (volume < 0 || volume > 1) errs.push({ field: 'volume', message: 'Volume out of range (0-1)' })
    setErrors(errs)
    return errs.length === 0
  }

  const save = async () => {
    if (!validate()) return
    setSaving(true)
    updatePreferences({
      sensory: {
        visual: { brightness, contrast, colorTemp, motionTolerance },
        auditory: {
          volumePreference: volume,
          frequencyFilters: [],
          spatialAudioTolerance: true,
          suddenSoundSensitivity
        },
        haptic: { intensity: 0.5, patterns: [], enabled: true }
      },
      cognitive: {
        explanationDepth,
        preferredLearning,
        chunkSize,
        attentionSpan,
        breakReminders
      }
    } as any)
    setSaving(false)
    setSaved(true)
    setTimeout(()=>setSaved(false), 1800)
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-2">Preferences</h2>
        <p className="text-sm text-gray-600">Adjust and persist adaptive settings (stored locally in your browser).</p>
      </div>

      {errors.length > 0 && (
        <div className="p-4 bg-red-50 border border-red-200 rounded flex gap-2 text-sm text-red-800">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <ul className="list-disc list-inside">
            {errors.map(e => <li key={e.field}>{e.field}: {e.message}</li>)}
          </ul>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-10">
        <section className="space-y-4">
          <h3 className="font-semibold text-lg">Sensory – Visual</h3>
          {numberField('Brightness', brightness, setBrightness, 0, 1, 0.01)}
          {numberField('Contrast', contrast, setContrast, 0, 2, 0.05)}
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">
              Color Temperature (K) <span className="text-xs text-gray-500">{colorTemp}</span>
            </label>
            <input
              type="range"
              min={2000}
              max={8000}
              step={100}
              value={colorTemp}
              onChange={e=>setColorTemp(Number(e.target.value))}
              className="w-full"
            />
          </div>
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">Motion Tolerance</label>
            <select
              value={motionTolerance}
              onChange={e=>setMotionTolerance(e.target.value as any)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="none">None (disable motion)</option>
              <option value="minimal">Minimal</option>
              <option value="moderate">Moderate</option>
              <option value="full">Full</option>
            </select>
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="font-semibold text-lg">Sensory – Auditory</h3>
            {numberField('Volume Preference', volume, setVolume, 0, 1, 0.01)}
          <label className="inline-flex gap-2 text-sm items-center">
            <input
              type="checkbox"
              checked={suddenSoundSensitivity}
              onChange={e=>setSuddenSoundSensitivity(e.target.checked)}
            />
            Sudden Sound Sensitivity
          </label>

          <h3 className="font-semibold text-lg pt-4">Cognitive</h3>
          <div className="space-y-1">
            <label className="block text-sm font-medium">Explanation Depth</label>
            <select
              value={explanationDepth}
              onChange={e=>setExplanationDepth(e.target.value as any)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="simple">Simple</option>
              <option value="intermediate">Intermediate</option>
              <option value="detailed">Detailed</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="block text-sm font-medium">Preferred Learning</label>
            <select
              value={preferredLearning}
              onChange={e=>setPreferredLearning(e.target.value as any)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="visual">Visual</option>
              <option value="verbal">Verbal</option>
              <option value="kinesthetic">Kinesthetic</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="block text-sm font-medium">Chunk Size</label>
            <select
              value={chunkSize}
              onChange={e=>setChunkSize(e.target.value as any)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="small">Small</option>
              <option value="medium">Medium</option>
              <option value="large">Large</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="block text-sm font-medium">Attention Span</label>
            <select
              value={attentionSpan}
              onChange={e=>setAttentionSpan(e.target.value as any)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="short">Short</option>
              <option value="variable">Variable</option>
              <option value="sustained">Sustained</option>
            </select>
          </div>
          <label className="inline-flex gap-2 text-sm items-center">
            <input
              type="checkbox"
              checked={breakReminders}
              onChange={e=>setBreakReminders(e.target.checked)}
            />
            Break Reminders
          </label>
        </section>
      </div>

      <div className="pt-4">
        <button
          onClick={save}
          disabled={saving}
          className="px-5 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          {saved ? 'Saved' : saving ? 'Saving...' : 'Save Preferences'}
        </button>
      </div>
    </div>
  )
}

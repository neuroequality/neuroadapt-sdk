import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { NeuroAdapt, PreferenceStore, UserPreferences, PreferenceStorage } from '@neuroadapt/core'

const LS_KEY = 'neuroadapt:prefs:v1'

class BrowserPreferenceStorage implements PreferenceStorage {
  async load() {
    if (typeof window === 'undefined') return null
    try {
      const raw = localStorage.getItem(LS_KEY)
      if (!raw) return null
      return JSON.parse(raw)
    } catch {
      return null
    }
  }
  async save(prefs: UserPreferences) {
    if (typeof window === 'undefined') return
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(prefs))
    } catch {}
  }
}

interface NeuroAdaptContextValue {
  neuro: NeuroAdapt | null
  preferences: UserPreferences | null
  updatePreferences: (partial: Partial<UserPreferences>) => void
  refresh: () => void
}

const Ctx = createContext<NeuroAdaptContextValue>({
  neuro: null,
  preferences: null,
  updatePreferences: () => {},
  refresh: () => {}
})

export const useNeuroAdapt = () => useContext(Ctx)

export const NeuroAdaptProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [neuro, setNeuro] = useState<NeuroAdapt | null>(null)
  const [preferences, setPreferences] = useState<UserPreferences | null>(null)

  useEffect(() => {
    const init = async () => {
      const n = new NeuroAdapt({ storage: new BrowserPreferenceStorage() })
      await n.initialize()
      setNeuro(n)
      setPreferences(n.getUserPreferences())
    }
    init()
  }, [])

  const updatePreferences = useCallback((partial: Partial<UserPreferences>) => {
    if (!neuro) return
    // Merge with existing
    const current = neuro.getUserPreferences()
    const merged: UserPreferences = {
      ...current,
      ...partial,
      sensory: { ...current.sensory, ...(partial as any).sensory },
      cognitive: { ...current.cognitive, ...(partial as any).cognitive }
    }
    // @ts-ignore PreferenceStore update is internal, we patch via store interface if exported
    // Instead adapt content by directly calling private store through update if available.
    // For now we rely on (neuro as any).preferences.update
    try {
      ;(neuro as any).preferences.update(merged)
      setPreferences(merged)
    } catch (e) {
      console.warn('Preference update failed', e)
    }
  }, [neuro])

  const refresh = useCallback(() => {
    if (!neuro) return
    setPreferences(neuro.getUserPreferences())
  }, [neuro])

  return <Ctx.Provider value={{ neuro, preferences, updatePreferences, refresh }}>{children}</Ctx.Provider>
}

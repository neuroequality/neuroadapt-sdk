# Changelog

## [1.0.0] - 2025-07-20
- Initial public scaffold with core, AI, VR, quantum, testing packages
- Added CI, release, accessibility test workflows

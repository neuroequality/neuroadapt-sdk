---
name: Feature request
about: Suggest an enhancement or new module
labels: enhancement
---

**Problem**
What problem are you solving?

**Proposed solution**

**Alternatives considered**

**Additional context**

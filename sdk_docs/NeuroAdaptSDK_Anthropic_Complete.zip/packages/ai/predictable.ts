export class PredictableAI {
  constructor(private config: { tone: string; explain: boolean }) {}
  respond(input: string): string {
    return `[${this.config.tone}] ${input}`;
  }
}
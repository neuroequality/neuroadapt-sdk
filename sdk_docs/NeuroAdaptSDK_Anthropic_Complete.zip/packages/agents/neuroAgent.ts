import { AnthropicClient } from '@neuroadapt/anthropic/client';

export class NeuroAgent {
  constructor(private client: AnthropicClient) {}

  async assist(userInput: string) {
    const result = await this.client.callClaude(userInput);
    return result?.content || 'No response';
  }
}
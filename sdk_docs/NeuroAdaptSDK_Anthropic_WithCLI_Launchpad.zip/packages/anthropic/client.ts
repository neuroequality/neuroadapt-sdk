import fetch from 'node-fetch';

export class AnthropicClient {
  constructor(private apiKey: string) {}

  async callClaude(prompt: string, model = 'claude-3-sonnet-20240229') {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': this.apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model,
        max_tokens: 512,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    return response.json();
  }
}
export class CognitiveLoadManager {
  constructor(private threshold = 75) {}
  check(load: number): boolean {
    return load > this.threshold;
  }
}
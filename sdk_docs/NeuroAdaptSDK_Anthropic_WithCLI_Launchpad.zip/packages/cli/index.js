#!/usr/bin/env node
console.log("🧠 Welcome to NeuroAdapt SDK CLI");

const args = process.argv.slice(2);
if (args[0] === "init") {
  console.log("🔧 Initializing NeuroAdapt project...");
  // Example template logic
} else if (args[0] === "help") {
  console.log("Available commands: init, help");
} else {
  console.log("Unknown command. Use 'neuro-sdk help'");
}
